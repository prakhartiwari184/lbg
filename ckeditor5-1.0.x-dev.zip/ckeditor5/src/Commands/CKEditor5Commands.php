<?php

declare(strict_types=1);

namespace Drupal\ckeditor5\Commands;

use Consolidation\OutputFormatters\StructuredData\RowsOfFields;
use Drupal\ckeditor5\Plugin\Editor\CKEditor5;
use Drupal\ckeditor5\SmartDefaultSettings;
use Drupal\Component\Utility\Html;
use Drupal\editor\EditorInterface;
use Drupal\editor\Entity\Editor;
use Drupal\filter\Entity\FilterFormat;
use Drupal\filter\FilterFormatInterface;
use Drush\Commands\DrushCommands;

/**
 * CKEditor 5 drush commands.
 *
 * @internal
 */
final class CKEditor5Commands extends DrushCommands {

  /**
   * Smart default settings utility.
   *
   * @var \Drupal\ckeditor5\SmartDefaultSettings
   */
  protected $smartDefaultSettings;

  /**
   * CKEditor5Commands constructor.
   *
   * @param \Drupal\ckeditor5\SmartDefaultSettings $smart_default_settings
   *   Smart default settings utility.
   */
  public function __construct(SmartDefaultSettings $smart_default_settings) {
    parent::__construct();
    $this->smartDefaultSettings = $smart_default_settings;
  }

  /**
   * Audits existing text formats for CKEditor 5 compatibility.
   *
   * @command ckeditor5:audit
   * @filter-output
   *
   * @option upgrade_only Analyzes text formats using CKEditor 5 text editors only.
   *
   * @default $options []
   *
   * @usage ckeditor5:audit
   *   Audits all text formats.
   * @usage ckeditor5:audit --upgrade_only
   *   Audits only the text formats currently using CKEditor 4.
   *
   * @validate-module-enabled ckeditor5
   *
   * @field-labels
   *   format_id: Text format
   *   editor_plugin_id: Text editor
   *   compatible: Compatible?
   *   details: Compatibility details
   * @default-fields format_id,editor_plugin_id,compatible,details
   *
   * @return \Consolidation\OutputFormatters\StructuredData\RowsOfFields
   *   Audit results formatted as table.
   */
  public function audit(array $options = ['upgrade_only' => self::OPT]): RowsOfFields {
    $table = [];

    $text_formats = FilterFormat::loadMultiple();
    foreach ($text_formats as $id => $text_format) {
      assert($text_format instanceof FilterFormatInterface);

      $editor = Editor::load($id);
      $editor_plugin_id = $editor ? $editor->getEditor() : NULL;

      // Only look at text formats currently using CKEditor 4.
      if ($options['upgrade_only'] && $editor_plugin_id !== 'ckeditor') {
        continue;
      }

      [$reconfigured_text_editor, $upgrade_messages] = $this->smartDefaultSettings->computeSmartDefaultSettings($editor, $text_format);
      assert($reconfigured_text_editor instanceof EditorInterface);
      $violations = CKEditor5::validatePair($reconfigured_text_editor, $text_format);

      $compatible = TRUE;
      $details = [];
      foreach ($upgrade_messages as $upgrade_message) {
        $details[] = '[UPGRADE] ' . Html::decodeEntities(strip_tags(str_replace('<br>', "\n\n", $upgrade_message))) . "\n";
      }
      foreach ($violations as $violation) {
        $validation_error = Html::decodeEntities(strip_tags(str_replace('<br>', "\n\n", $violation->getMessage()))) . "\n";

        // If there is a fundamental incompatibility, set $compatible = FALSE
        // and return this violation as the only detail.
        if ($violation->getPropertyPath() === '') {
          if ($compatible) {
            $compatible = FALSE;
            $details = [];
          }
          $details[] = $validation_error;
          break;
        }

        $details[] = $validation_error;
      }

      $table[] = [
        'format_id' => $id,
        'editor_plugin_id' => $editor_plugin_id,
        'compatible' => $compatible ? '✅' : '❌',
        'details' => implode("\n\n", $details),
      ];
    }
    return new RowsOfFields($table);
  }

}
