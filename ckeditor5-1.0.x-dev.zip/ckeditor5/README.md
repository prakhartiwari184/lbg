## CONTENTS OF THIS FILE

- Introduction
- Installation
- Development
- Custom CKEditor 5 plugins in modules
- Toolbar Admin
- Toolbar Configuration
- Maintainers

## INTRODUCTION

Provides the CKEditor 5 rich text editor for use with Drupal.

- For a full description of the module, visit the project page:
  https://drupal.org/project/ckeditor5

- To submit bug reports and feature suggestions, or to track changes:
  https://drupal.org/project/issues/ckeditor5

## INSTALLATION

- Install as you would normally install a contributed Drupal module.
  See https://www.drupal.org/docs/extending-drupal/installing-modules for more
  information.

## DEVELOPMENT

CKEditor plugins are created via a build process.

In the module root directory, first install dependencies for both applications:

```
yarn install
```

Perform an initial build:
_Note that the initial build can take a few minutes due to it generating
several dependencies that will be available for subsequent builds._

```
yarn build
```

Trigger the build process any time a source file changes:

```
yarn watch
```

## CUSTOM CKEDITOR 5 PLUGINS IN MODULES

When creating CKEditor 5 plugins in Drupal modules, it is recommended to begin
with the template in `ckeditor5_plugin_starter_template`. This automates several
steps that required to develop CKEditor 5 plugins (most of them steps not
specific to Drupal).

## TOOLBAR ADMIN

Contributed plugins may provide an icon for their toolbar items by adding a
background-image using the css class:
`.ckeditor5-toolbar-button-{pluginToolbarItem}`

Add a library with any styles needed for your toolbar buttons using the
`admin_library` key within the `drupal` section of the plugin config, and this
library will be loaded when alongside the toolbar UI.

The toolbar admin UI loads in `#ckeditor5-toolbar-app` and parses the available
toolbar buttons listed in `#ckeditor5-toolbar-buttons-available`. The selected
buttons are written to the value of `#ckeditor5-toolbar-buttons-selected`.

In addition to native assistive tech announcements, the the UI app announces the
following events to Drupal's aria-live region:

- onButtonMovedActive - When an inactive button is moved to the active button
  list.
- onButtonCopiedActive - When a reusable button (such as a divider) is added to
  the active button list
- onButtonMovedInactive - A button is removed from the active button list.

## MAINTAINERS

Current maintainers:

- Peter Weber (https://www.drupal.org/u/zrpnr)
