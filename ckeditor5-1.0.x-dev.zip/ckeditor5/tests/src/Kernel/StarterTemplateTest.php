<?php

namespace Drupal\Tests\ckeditor5\Kernel;

use Drupal\Component\Serialization\Json;
use Drupal\KernelTests\KernelTestBase;

/**
 * Tests to ensure the starter template files remain current.
 *
 * @group ckeditor5
 * @internal
 */
class StarterTemplateTest extends KernelTestBase {

  /**
   * Confirm starter template files are current with module files.
   *
   * The starter template includes several copies of files used by the
   * CKEditor 5 module for JavaScript plugin builds, but with slightly modified
   * to make them more suitable for use in contrib. To ensure the two versions
   * of these very similar (or identical) files remain in sync, this test
   * monitors changes to them and ensures files that should be identical still
   * are, and non-identical files should still receive equivalent changes.
   */
  public function testStarterTemplateFilesCurrent() {
    $module_path = $this->container->get('extension.list.module')->getPath('ckeditor5');

    $package_json_template = "$module_path/ckeditor5_plugin_starter_template/js/package.json";
    $package_json = "$module_path/package.json";
    $this->assertFileExists($package_json);
    $this->assertFileExists($package_json_template);

    // Ensure that crucial parts of the package.json files match.
    $this->assertSame($this->getCrucialPackageJsonSubsets($package_json), $this->getCrucialPackageJsonSubsets($package_json_template));

    $webpack_config_template = "$module_path/ckeditor5_plugin_starter_template/js/webpack.config.js";
    $webpack_config = "$module_path/webpack.config.js";
    $this->assertFileExists($webpack_config_template);
    $this->assertFileExists($webpack_config);

    $webpack_config_hash = md5_file($webpack_config);
    $webpack_config_template_hash = md5_file($webpack_config_template);

    $this->assertSame('bae8d8c966e389d8961307df797c778b', $webpack_config_hash, "This test has detected changes in $webpack_config. Please see if any of the changes made in this file should also be made in $webpack_config_template, an equivalent version of this file provided to module developers. Once it's confirmed these two files are current with one another, change the first argument in this test to $webpack_config_hash so it will pass.");
    $this->assertSame('8fb7dbd0ec6f73973bf1442c288207a0', $webpack_config_template_hash, "This test has detected changes in $webpack_config_template. Please see if any of the changes made in this file should also be made in $webpack_config, the file this template is based on. Once it's confirmed these two files are current with one another, change the first argument in this test to $webpack_config_template_hash so it will pass.");
  }

  /**
   * Get crucial package.json subsets.
   *
   * @param string $package_json_path
   *   Path for a package.json file.
   *
   * @return array
   *   An array that include crucial parts of the package.json.
   */
  protected static function getCrucialPackageJsonSubsets(string $package_json_path): array {
    $safe_to_be_out_of_sync = ['name', 'version', 'description', 'author', 'license', 'scripts'];
    $json = JSON::decode(file_get_contents($package_json_path));
    $dev_dependencies_to_skip = ['jsdom'];
    $json['devDependencies'] = array_filter($json['devDependencies'], function ($value, $key) use ($dev_dependencies_to_skip) {
      if (in_array($key, $dev_dependencies_to_skip)) {
        return FALSE;
      }
      return substr($key, 0, 9) !== '@ckeditor' || $key === '@ckeditor/ckeditor5-dev-utils';
    }, ARRAY_FILTER_USE_BOTH);
    return array_diff_key($json, array_flip($safe_to_be_out_of_sync));
  }

}
