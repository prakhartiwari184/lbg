const path = require('path');
const { execShellCommand } = require('./utils');
const { copyFile, rmdir, mkdir, rename, readdir, appendFile, readFile } =
  require('fs').promises;
const os = require('os');

// cSpell:words subpackages

/**
 * Gets directory name for a tmp directory.
 *
 * @returns {string}
 */
const getTmpDir = () => {
  const dateString = Date.now().toString(36);
  const randomness = Math.random().toString(36).substr(2);
  return os.tmpdir() + '/' + dateString + randomness;
};

(async () => {
  const buildPath = './js/build';

  console.log('🗄   Creating back up of the old build files');
  const tmpDir = getTmpDir();
  await rename(buildPath, tmpDir);
  await mkdir(buildPath);

  const restoreOldBuild = async () => {
    await rmdir(buildPath, { recursive: true });
    await rename(tmpDir, buildPath);
  };

  console.log('🏗   Building Drupal plugins from sources');
  await execShellCommand('yarn build')
    .then(async (stdout) => {
      console.log(stdout);

      console.log(
        '🔥  Build was successful, copying files from CKEditor 5 build',
      );
      const ckeditorPath = './node_modules/@ckeditor';

      /**
       * Declare an array that defines what needs to be copied over.
       *
       * @prop {string} pack
       *   The name of the CKEditor package, used to determine the source
       *   directory.
       * @prop {Array} files
       *   An array of files to be copied over from the package.
       * @prop {string} [folder]
       *   Folder that allows copying files from outside the subpackages.
       */
      const process = [
        {
          pack: 'ckeditor5-alignment',
          files: ['build/alignment.js'],
        },
        {
          pack: 'ckeditor5-basic-styles',
          files: ['build/basic-styles.js'],
        },
        {
          pack: 'ckeditor5-block-quote',
          files: ['build/block-quote.js'],
        },
        {
          pack: 'ckeditor5-editor-classic',
          files: ['build/editor-classic.js'],
        },
        {
          pack: 'ckeditor5-editor-decoupled',
          files: ['build/editor-decoupled.js'],
        },
        {
          pack: 'ckeditor5-essentials',
          files: ['build/essentials.js'],
        },
        {
          pack: 'ckeditor5-heading',
          files: ['build/heading.js'],
        },
        {
          pack: 'ckeditor5-horizontal-line',
          files: ['build/horizontal-line.js'],
        },
        {
          pack: 'ckeditor5-image',
          files: ['build/image.js'],
        },
        {
          pack: 'ckeditor5-indent',
          files: ['build/indent.js'],
        },
        {
          pack: 'ckeditor5-language',
          files: ['build/language.js'],
        },
        {
          pack: 'ckeditor5-link',
          files: ['build/link.js'],
        },
        {
          pack: 'ckeditor5-list',
          files: ['build/list.js'],
        },
        {
          pack: 'ckeditor5-paste-from-office',
          files: ['build/paste-from-office.js'],
        },
        {
          pack: 'ckeditor5-remove-format',
          files: ['build/remove-format.js'],
        },
        {
          pack: 'ckeditor5-source-editing',
          files: ['build/source-editing.js'],
        },
        {
          pack: 'ckeditor5-table',
          files: ['build/table.js'],
        },
        {
          pack: 'ckeditor5-html-support',
          files: ['build/html-support.js'],
        },
        {
          pack: 'ckeditor5-special-characters',
          files: ['build/special-characters.js'],
        },
        {
          pack: 'ckeditor5-dll',
          files: ['build/ckeditor5-dll.js'],
          folder: '../ckeditor5',
        },
      ];

      await rmdir(`${buildPath}/translations`).catch(() => {
        // Nothing to do if the directory doesn't exist.
      });
      await mkdir(`${buildPath}/translations`);

      // Use Array.reduce for sequential processing to avoid corrupting the
      // contents of the concatenated translation files.
      await process.reduce((previous, { pack, files = [], folder = null }) => {
        const sourceFolder =
          folder !== null
            ? `${ckeditorPath}/${folder}`
            : `${ckeditorPath}/${pack}`;
        const packageTranslationPath = `${sourceFolder}/build/translations`;

        return previous.then(() => {
          return Promise.all([
            ...files.map((file) => {
              const name = path.basename(`${sourceFolder}/${file}`);
              return copyFile(
                `${sourceFolder}/${file}`,
                `${buildPath}/${name}`,
              );
            }),
            readdir(packageTranslationPath, { withFileTypes: true })
              .then(async (translationFiles) => {
                return translationFiles.map(async (translationFile) => {
                  if (!translationFile.isDirectory()) {
                    // Translation files are concatenated to a single translation
                    // file to avoid having to make multiple network requests to
                    // various translation files. As a trade off, this leads into
                    // some redundant translations depending on configuration.
                    await readFile(
                      `${packageTranslationPath}/${translationFile.name}`,
                    ).then(async (contents) => {
                      return appendFile(
                        `${buildPath}/translations/${translationFile.name}`,
                        contents,
                      );
                    });
                  }
                }, Promise.resolve());
              })
              .catch(() => {
                // Do nothing as it's expected that not all packages ship translations.
              }),
          ]).then(() => {
            console.log(`✅  ${pack} updated`);
          });
        });
      }, Promise.resolve());
    })
    .catch(async () => {
      await restoreOldBuild();

      process.exit(1);
    });
})();
