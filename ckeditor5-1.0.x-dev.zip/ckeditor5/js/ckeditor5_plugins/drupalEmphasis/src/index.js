// cspell:ignore drupalemphasis

import DrupalEmphasis from './drupalemphasis';

/**
 * @internal
 */
export default {
  DrupalEmphasis,
};
