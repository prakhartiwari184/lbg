Adaptive Theme 2.0
