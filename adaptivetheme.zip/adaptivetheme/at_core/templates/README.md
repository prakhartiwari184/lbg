# Templates

Drupal core template overrides. By default all sub-themes are generated
with page.html.twig.

If you select the option to include templates when generating a 
sub-theme the templates in this directory are copied and placed in 
your sub-themes templates directory.

If you manually create a sub-theme you can pick and choose which 
templates you want to copy and modify.


