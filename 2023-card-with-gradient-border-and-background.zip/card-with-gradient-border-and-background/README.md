# Card with gradient border and background

A Pen created on CodePen.io. Original URL: [https://codepen.io/AdityaTiwari/pen/ZExjbwJ](https://codepen.io/AdityaTiwari/pen/ZExjbwJ).

