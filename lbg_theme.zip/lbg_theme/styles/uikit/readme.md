Getting started...

ATD8 uses grunt-sass (Libsass), Susy, Modular Scale, PostCSS (for
browser extensions and SourceMaps), and various other packages.

You need nodejs and grunt installed to grab all the packages and
run the task runners.

https://nodejs.org/ for node package manager (npm) for node modules https://www.npmjs.com/
http://gruntjs.com/ our task runner + installing grunt packages.

Get all that installed then fire off some commands from the theme root...

npm install
grunt watch (the default watch task watches the UIKit).

Check the Gruntfile.js for other tasks or create your own.

Now edit some SCSS files in the UIKit, and remember to turn off CSS aggregation in Drupal.
